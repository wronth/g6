<?php

// 1. Database connection details
$host = '127.0.0.1';
$db_name = 'cardinal_pitstop'; // <-- Your new database name
$username = 'root';
$password = ''; // Your XAMPP root password (if you set one)

// 2. Create a "DSN" string
$port = 3307;
$dsn = "mysql:host=$host;port=$port;dbname=$db_name;charset=utf8mb4";

// 3. Try to connect
try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // You are now connected!

} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

?>