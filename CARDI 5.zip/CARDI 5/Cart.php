<?php
session_start();
// Make sure db_connect.php is in the 'CARDI 3' folder
require 'db_connect.php'; 

// ---
// Placeholder for your login system.
// This is a demo and assumes user_id = 1.
if (!isset($_SESSION['user_id'])) {
    // Let's find a user, or create one for demo purposes
    $stmt = $pdo->query("SELECT user_id FROM users LIMIT 1");
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['user_id'] = $user['user_id'];
    } else {
        // This is just a fallback for an empty demo database.
        // You should create a user in your `users` table
        $_SESSION['user_id'] = 1; 
    }
}
$user_id = $_SESSION['user_id'];
// ---

// Fetch all cart items for this user from the database
$cart_items_by_store = [];
$grand_total = 0;
$items = []; // Initialize $items as an empty array

try {
    $stmt = $pdo->prepare("
        SELECT 
            ci.item_id,
            ci.quantity,
            mi.name,
            mi.price,
            mi.image_url,
            s.name AS store_name,
            s.store_id
        FROM cart_items ci
        JOIN menu_items mi ON ci.item_id = mi.item_id
        JOIN stores s ON mi.store_id = s.store_id
        WHERE ci.user_id = ?
        ORDER BY s.name, mi.name
    ");
    $stmt->execute([$user_id]);
    $items = $stmt->fetchAll(); // Now $items is populated

    // Group the items by store name
    foreach ($items as $item) {
        $cart_items_by_store[$item['store_name']][] = $item;
    }

} catch (PDOException $e) {
    // Don't kill the page, just show an error
    error_log("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
    :root { --mapua-red: #C60C30; --white: #FFFFFF; --dark-text: #333333; --light-bg: #F8F9FA; --text-muted: #6c757d; --border-color: #E9ECEF; }
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: "Segoe UI", sans-serif; }
    body { background: var(--light-bg); color: var(--dark-text); }
    .navbar { background: var(--mapua-red); color: white; display: flex; justify-content: space-between; align-items: center; padding: 16px 24px; box-shadow: 0 2px 5px rgba(0,0,0,0.15); }
    .navbar-left { display: flex; align-items: center; gap: 12px; }
    .navbar-left h1 { font-size: 1.25rem; font-weight: 700; }
    .navbar-left p { font-size: 0.875rem; color: #f0f0f0; }
    .back-arrow { font-size: 1.5rem; cursor: pointer; color: white; text-decoration: none; }
    .container { max-width: 900px; margin: 24px auto; padding: 0 20px; }
    .cart-store-group { background: var(--white); border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); margin-bottom: 24px; }
    .cart-store-group h2 { font-size: 1.2rem; padding: 16px 20px; border-bottom: 1px solid var(--border-color); }
    .cart-item { display: flex; align-items: center; padding: 16px 20px; border-bottom: 1px solid var(--border-color); gap: 16px; }
    .cart-item:last-child { border-bottom: none; }
    .cart-item img { width: 60px; height: 60px; border-radius: 6px; object-fit: cover; }
    .item-details { flex-grow: 1; }
    .item-details h3 { font-size: 1rem; font-weight: 600; }
    .item-details p { font-size: 0.9rem; color: var(--text-muted); }
    .item-price { font-size: 1rem; font-weight: 600; }
    .empty-cart { text-align: center; padding: 60px 20px; background: var(--white); border-radius: 8px; }
    .empty-cart p { font-size: 1.1rem; font-weight: 600; margin-bottom: 8px; }
    .empty-cart a { background: var(--mapua-red); color: white; border: none; padding: 12px 24px; border-radius: 9999px; font-weight: 600; cursor: pointer; text-decoration: none; display: inline-block; margin-top: 16px; }
    .checkout-summary { background: var(--white); border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); padding: 20px; }
    .summary-row { display: flex; justify-content: space-between; font-size: 1.2rem; font-weight: 700; margin-bottom: 20px; }
    #place-order-btn { background: var(--mapua-red); color: white; border: none; padding: 16px; width: 100%; border-radius: 8px; font-size: 1.1rem; font-weight: 600; cursor: pointer; }
    #place-order-btn:disabled { background: var(--text-muted); }
</style>
</head>
<body>

    <header class="navbar">
        <div class="navbar-left">
            <a href="customer_dashboard.php" class="back-arrow" aria-label="Back to home">&#8592;</a>
            <div>
                <h1>Shopping Cart</h1>
                <p>Review your order</p>
            </div>
        </div>
    </header>

    <main class="container">
        <?php if (empty($items)): ?>
            <div class="empty-cart">
                <p>Your cart is empty</p>
                <a href="customer_dashboard.php">Browse Stores</a>
            </div>
        <?php else: ?>
            <!-- Loop through each STORE'S group of items -->
            <?php foreach ($cart_items_by_store as $store_name => $store_items): ?>
                <div class="cart-store-group">
                    <h2><?php echo htmlspecialchars($store_name); ?></h2>
                    <?php $store_subtotal = 0; ?>
                    <!-- Loop through each ITEM in that store's group -->
                    <?php foreach ($store_items as $item): ?>
                        <div class="cart-item">
                            <img src="<?php echo htmlspecialchars($item['image_url'] ?? 'https://placehold.co/100x100/eee/ccc?text=No+Img'); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            <div class="item-details">
                                <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                <p>Quantity: <?php echo $item['quantity']; ?></p>
                            </div>
                            <div class="item-price">
                                <?php
                                $item_total = $item['price'] * $item['quantity'];
                                $store_subtotal += $item_total;
                                echo '₱' . number_format($item_total, 2);
                                ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php $grand_total += $store_subtotal; ?>
            <?php endforeach; ?>

            <!-- Checkout Summary Box -->
            <div class="checkout-summary">
                <div class="summary-row">
                    <span>Total</span>
                    <span><?php echo '₱' . number_format($grand_total, 2); ?></span>
                </div>
                <button id="place-order-btn">Place Order</button>
            </div>
        <?php endif; ?>
    </main>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const placeOrderBtn = document.getElementById('place-order-btn');

        if (placeOrderBtn) {
            placeOrderBtn.addEventListener('click', () => {
                placeOrderBtn.disabled = true;
                placeOrderBtn.textContent = 'Placing Order...';

                fetch('checkout_api.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'checkout' }) // Send a checkout action
                })
                .then(response => {
                    if (!response.ok) {
                        // If server returns an error (like 500), get the text
                        return response.text().then(text => { throw new Error(text) });
                    }
                    return response.json(); // Otherwise, parse JSON
                })
                .then(data => {
                    if (data.error) {
                        throw new Error(data.error);
                    }
                    
                    if (data.success) {
                        alert('Order placed successfully! Redirecting to your orders page.');
                        window.location.href = 'Orders.php'; // Redirect to Orders page
                    }
                })
                .catch(err => {
                    console.error('Checkout error:', err);
                    // Check for PHP error HTML in the response
                    let errorText = err.message;
                    if (errorText.includes('<br />')) {
                        errorText = "A PHP error occurred. Please check the `checkout_api.php` file for typos.";
                    }
                    alert('Error placing order: ' + errorText);
                    placeOrderBtn.disabled = false;
                    placeOrderBtn.textContent = 'Place Order';
                });
            });
        }
    });
    </script>

</body>
</html>

