<?php session_start(); // Required to identify the user ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
}

body {
    background: #f8f9fa;
    color: #1f2937;
}

/* Navbar */
.navbar {
    background: #C60C30;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 24px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.15);
    position: sticky; /* Make navbar sticky */
    top: 0;
    z-index: 100;
}

.navbar-left {
    display: flex;
    align-items: center;
    gap: 16px; 
}

.navbar-left h1 {
    font-size: 1.25rem;
    font-weight: 700;
}

.navbar-left p {
    font-size: 0.875rem;
    color: #f0f0f0; 
}

.back-arrow {
    font-size: 1.5rem;
    cursor: pointer;
    color: white;
    text-decoration: none;
}

.navbar-right .filter-btn {
    background: transparent;
    border: none;
    color: white;
    cursor: pointer;
    padding: 0; 
}

.navbar-right .filter-btn svg {
    width: 24px;
    height: 24px;
}


/* --- EMPTY STATE STYLES --- */
.cart-container {
    display: flex;
    justify-content: center;
    /* align-items: center; <-- This is removed so list starts at top */
    min-height: calc(100vh - 80px); /* Use min-height */
    padding: 24px 0;
}

.cart-content {
    text-align: center;
    color: #374151;
    width: 100%;
    max-width: 960px; /* Wider max-width for order list */
    padding: 0 15px;
}

.cart-icon {
    background: #e5e7eb;
    border-radius: 50%;
    width: 120px;
    height: 120px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0 auto 20px;
}

.cart-icon svg {
    width: 64px;
    height: 64px;
}

.empty-text {
    font-size: 1.1rem;
    font-weight: 600; 
    margin-bottom: 8px;
}

.subtext {
    color: #6b7280;
    margin-bottom: 24px; 
}

.browse-btn {
    background: #C60C30;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 9999px; 
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
    text-decoration: none;
    display: inline-block;
}

.browse-btn:hover {
    background: #A30A27; 
}


/* --- NEW ORDER LIST STYLES --- */
.orders-list-title {
    font-size: 1.5rem;
    font-weight: 700;
    text-align: left;
    margin-bottom: 16px;
}

.order-card {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    padding: 20px;
    margin-bottom: 16px;
    text-align: left;
}

.order-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #e5e7eb;
    padding-bottom: 12px;
    margin-bottom: 12px;
}

.order-card-header h3 {
    font-size: 1.1rem;
    font-weight: 600;
}

.order-status {
    font-size: 0.9rem;
    font-weight: 600;
    padding: 4px 10px;
    border-radius: 50px;
    text-transform: capitalize;
}
.order-status.pending { background-color: #fffbeb; color: #b45309; }
.order-status.confirmed { background-color: #eff6ff; color: #2563eb; }
.order-status.preparing { background-color: #eff6ff; color: #2563eb; }
.order-status.ready_for_pickup { background-color: #ecfdf5; color: #065f46; }
.order-status.completed { background-color: #f0fdf4; color: #15803d; }
.order-status.cancelled { background-color: #fef2f2; color: #b91c1c; }


.order-timestamp {
    font-size: 0.9rem;
    color: #6b7280;
    margin-bottom: 16px;
}

.order-items-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.order-item {
    display: flex;
    align-items: center;
    gap: 12px;
}

.order-item-img {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 6px;
    flex-shrink: 0;
}

.order-item-info {
    flex-grow: 1;
}
.order-item-info strong {
    font-size: 1rem;
    color: #1f2937;
}
.order-item-info p {
    font-size: 0.9rem;
    color: #6b7280;
    margin: 2px 0 0;
}

.order-card-footer {
    border-top: 1px solid #e5e7eb;
    padding-top: 16px;
    margin-top: 16px;
    text-align: right;
    font-size: 1.1rem;
    font-weight: 700;
    color: #1f2937;
}
.order-card-footer span {
    margin-right: 12px;
    font-weight: 500;
    color: #6b7280;
    font-size: 1rem;
}

</style>
</head>
<body>
    <header class="navbar">
        <div class="navbar-left">
            <a href="customer_dashboard.php" class="back-arrow" aria-label="Back to home">&#8592;</a>
            <div>
                <h1>My Orders</h1>
                <p>Track your food orders</p>
            </div>
        </div>
        <div class="navbar-right">
            <button class="filter-btn" aria-label="Filter orders">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M1.5 1.5A.5.5 0 0 1 2 1h12a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.128.334L10 7.334V11.5a.5.5 0 0 1-.29.45l-2 1A.5.5 0 0 1 7 12.5V7.334L1.628 3.834A.5.5 0 0 1 1.5 3.5v-2zM2 2v1.083l6 4.333v4.333l1-.5V7.417l6-4.333V2H2z"/>
                </svg>
            </button>
        </div>
    </header>

    <main class="cart-container" id="main-container">
        <div class="cart-content" id="orders-content">
            
            <!-- This is the default "empty" state -->
            <div class="cart-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="#9ca3af" viewBox="0 0 24 24">
                    <path d="M21.99,6.88,12,1.22,2.01,6.88V17.12L12,22.78l9.99-5.66V6.88ZM12,3.34,19.99,8,12,12.66,4.01,8,12,3.34ZM4,15.9,11,19.9v-6.1L4,9.7V15.9Z"/>
                </svg>
            </div>
            <p class="empty-text">No orders yet</p>
            <p class="subtext">Start ordering from our amazing stores!</p>
            <a href="customer_dashboard.php" class="browse-btn">
                Browse Stores
            </a>
            <!-- End of default "empty" state -->

            </div>
    </main>

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const mainContainer = document.getElementById("main-container");
            const ordersContent = document.getElementById("orders-content");
            
            // 1. Fetch orders from our new API
            fetch('get_orders_api.php')
                .then(response => response.json())
                .then(orders => {
                    
                    if (orders.error) {
                        throw new Error(orders.error);
                    }

                    // 2. Check if any orders exist
                    if (orders.length > 0) {
                        // If we have orders, change the layout
                        mainContainer.style.alignItems = "flex-start"; // Align list to top
                        ordersContent.style.textAlign = "left";

                        let ordersHtml = '<h2 class="orders-list-title">Your Orders</h2>';

                        // 3. Loop through orders and build HTML
                        orders.forEach(order => {
                            // Build HTML for items in this specific order
                            const itemsHtml = order.items.map(item => `
                                <div class="order-item">
                                    <img src="${item.image_url || 'https://placehold.co/100x100/eee/ccc?text=No+Img'}" alt="${item.item_name_snapshot}" class="order-item-img">
                                    <div class="order-item-info">
                                        <strong>${item.item_name_snapshot}</strong>
                                        <p>₱${Number(item.price_at_order).toFixed(2)} (x${item.quantity})</p>
                                    </div>
                                </div>
                            `).join('');

                            // Build the full order card
                            ordersHtml += `
                                <div class="order-card">
                                    <div class="order-card-header">
                                        <h3>${order.store_name}</h3>
                                        <span class="order-status ${order.status.toLowerCase().replace(/ /g, '_')}">${order.status.replace('_', ' ')}</span>
                                    </div>
                                    <p class="order-timestamp">Placed: ${new Date(order.order_time).toLocaleString()} | Order ID: #${order.order_id}</p>
                                    <div class="order-items-list">
                                        ${itemsHtml}
                                    </div>
                                    <div class="order-card-footer">
                                        <span>Pickup Code: <strong>${order.pickup_code}</strong></span>
                                        <span>Total: ₱${Number(order.total_amount).toFixed(2)}</span>
                                    </div>
                                </div>
                            `;
                        });

                        // 4. Inject the built HTML into the content area
                        ordersContent.innerHTML = ordersHtml;

                    } 
                    // 5. If orders.length === 0, we do nothing. The default "No orders yet" HTML will remain.
                })
                .catch(err => {
                    console.error("Error fetching orders:", err);
                    ordersContent.innerHTML = `<p class="empty-text" style="color: red;">Error: ${err.message}</p><p>Could not load your orders. Please try again later.</p>`;
                });
        });
    </script>
</body>
</html>
