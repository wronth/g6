<?php
session_start();
require 'db_connect.php'; 
header('Content-Type: application/json');

// ---
// Ensure user is logged in (using the same demo logic)
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Authentication required. Please log in first.']);
    exit;
}
$user_id = $_SESSION['user_id'];
// ---

try {
    $data = json_decode(file_get_contents('php://input'), true);

    $order_id = $data['order_id'] ?? null;
    $store_id = $data['store_id'] ?? null;
    $rating = $data['rating'] ?? 0;
    $review_text = $data['review_text'] ?? '';
    
    // Basic validation
    if (!$order_id || !$store_id || $rating < 1 || $rating > 5) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid data provided. Rating must be 1-5.']);
        exit;
    }

    // Insert the new rating into the store_ratings table
    $stmt = $pdo->prepare("
        INSERT INTO store_ratings (user_id, store_id, order_id, rating, review_text)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$user_id, $store_id, $order_id, $rating, $review_text]);

    echo json_encode(['success' => true]);

} catch (PDOException $e) {
    http_response_code(500);
    // Specifically handle the case where the user tries to rate the same order twice
    if ($e->getCode() == '23000') {
        echo json_encode(['error' => 'You have already submitted a rating for this order.']);
    } else {
        error_log("Rating database error: " . $e->getMessage());
        echo json_encode(['error' => 'A server error occurred during submission.']);
    }
}
?>
