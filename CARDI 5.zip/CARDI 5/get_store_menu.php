<?php
// This API file fetches all data for a menu page.
require 'db_connect.php'; 
header('Content-Type: application/json');

$store_name = $_GET['store_name'] ?? '';

if (empty($store_name)) {
    echo json_encode(['error' => 'Store name not provided.']);
    exit;
}

try {
    // 1. Get store details (and average rating)
    $stmt_store = $pdo->prepare("
        SELECT 
            s.store_id, 
            s.name, 
            s.description, 
            s.banner_image_url, 
            s.avg_wait_time,
            AVG(sr.rating) as avg_rating,
            COUNT(sr.rating) as review_count
        FROM stores s
        LEFT JOIN store_ratings sr ON s.store_id = sr.store_id
        WHERE s.name = ?
        GROUP BY s.store_id
    ");
    $stmt_store->execute([$store_name]);
    $store_info = $stmt_store->fetch();

    if (!$store_info) {
        echo json_encode(['error' => 'Store not found.']);
        exit;
    }

    // 2. Get menu items for this store
    $stmt_items = $pdo->prepare("
        SELECT item_id, name, price, image_url, is_available 
        FROM menu_items 
        WHERE store_id = ?
    ");
    $stmt_items->execute([$store_info['store_id']]);
    $menu_items = $stmt_items->fetchAll();

    // 3. Combine and return
    $response = [
        'store_info' => $store_info,
        'menu_items' => $menu_items
    ];

    echo json_encode($response);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
