<?php
require 'db_connect.php'; 
session_start();
header('Content-Type: application/json');

// ---
// Placeholder for your login system.
// This is a demo and assumes user_id = 1.
if (!isset($_SESSION['user_id'])) {
    // Let's find a user, or create one for demo purposes
    $stmt = $pdo->query("SELECT user_id FROM users LIMIT 1");
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['user_id'] = $user['user_id'];
    } else {
        // This is just a fallback for an empty demo database.
        $_SESSION['user_id'] = 1; 
    }
}
$user_id = $_SESSION['user_id'];
// ---

if ($user_id === 0) {
    echo json_encode([]); // Return empty array if not logged in
    exit;
}

try {
    // 1. Get all main orders for this user
    $stmt_orders = $pdo->prepare("
        SELECT 
            o.order_id,
            o.store_id,
            o.total_amount,
            o.status,
            o.order_time,
            o.pickup_code,
            s.name AS store_name
        FROM orders o
        JOIN stores s ON o.store_id = s.store_id
        WHERE o.user_id = ?
        ORDER BY o.order_time DESC
    ");
    $stmt_orders->execute([$user_id]);
    $orders = $stmt_orders->fetchAll();

    if (empty($orders)) {
        echo json_encode([]); // Send empty array, not an error
        exit;
    }

    // 2. Get all items for all the user's orders in one query
    $order_ids = array_column($orders, 'order_id');
    $placeholders = implode(',', array_fill(0, count($order_ids), '?'));

    $stmt_items = $pdo->prepare("
        SELECT 
            oi.order_id, 
            oi.item_name_snapshot, 
            oi.price_at_order, 
            oi.quantity, 
            mi.image_url
        FROM order_items oi
        LEFT JOIN menu_items mi ON oi.item_id = mi.item_id
        WHERE oi.order_id IN ($placeholders)
    ");
    $stmt_items->execute($order_ids);
    
    // Group items by their order_id
    $all_items = $stmt_items->fetchAll(PDO::FETCH_GROUP | PDO::FETCH_ASSOC);

    // 3. Attach items to their respective orders
    foreach ($orders as $key => $order) {
        $orders[$key]['items'] = $all_items[$order['order_id']] ?? [];
    }

    // 4. Send the complete data
    echo json_encode($orders);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
