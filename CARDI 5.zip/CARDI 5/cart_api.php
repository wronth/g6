<?php
// This API file adds items to the cart in the database.
require 'db_connect.php'; 
session_start(); // Get the logged-in user
header('Content-Type: application/json');

// ---
// NOTE: This is a placeholder for your real login system.
// In your login.php, you must set $_SESSION['user_id'] after a successful login.
// For this demo, I'll hardcode user_id = 1 (the first user).
// You MUST replace this with your real login system.
if (!isset($_SESSION['user_id'])) {
    // Let's find a user, or create one for demo purposes
    $stmt = $pdo->query("SELECT user_id FROM users LIMIT 1");
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['user_id'] = $user['user_id'];
    } else {
        // This is just a fallback for an empty demo database.
        $_SESSION['user_id'] = 1; 
    }
}
// ---

$user_id = $_SESSION['user_id'] ?? 0;

if ($user_id === 0) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'You must be logged in to add items to your cart.']);
    exit;
}

// Get the JSON data sent from the JavaScript
$data = json_decode(file_get_contents('php://input'), true);
$item_id = $data['item_id'] ?? 0;

if ($item_id === 0) {
    http_response_code(400); // Bad Request
    echo json_encode(['error' => 'Invalid item.']);
    exit;
}

try {
    // This SQL query adds 1 to the quantity if the item is already in the cart.
    $stmt = $pdo->prepare("
        INSERT INTO cart_items (user_id, item_id, quantity) 
        VALUES (?, ?, 1)
        ON DUPLICATE KEY UPDATE quantity = quantity + 1
    ");
    $stmt->execute([$user_id, $item_id]);
    
    echo json_encode(['success' => true, 'message' => 'Item added to cart!']);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
