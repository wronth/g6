<?php session_start(); // Start session to track user ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Hall Menu</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
    /* * --- CSS STYLES --- 
     * The styles are an exact copy of the shared menu template.
     */
    :root {
        --mapua-red: #C60C30; 
        --white: #FFFFFF;
        --dark-text: #333333;
        --light-bg: #F8F9FA; 
        --text-muted: #6c757d;
        --yellow-accent: #FFCC00; 
        --border-color: #E9ECEF;
        --red-icon: #C60C30;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; font-family: Arial, sans-serif; }
    body { background-color: var(--light-bg); color: var(--dark-text); }
    a { text-decoration: none; color: inherit; }
    .menu-header { background-color: var(--mapua-red); color: var(--white); padding: 10px 20px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); }
    .header-content { display: flex; align-items: center; max-width: 1200px; margin: 0 auto; }
    .back-link { color: var(--white); font-size: 1.2em; margin-right: 15px; padding: 5px; }
    .stall-info { flex-grow: 1; }
    .stall-info h1 { font-size: 1.2em; margin: 0; font-weight: bold; }
    .stall-info p { font-size: 0.8em; margin: 0; opacity: 0.8; }
    .header-actions { display: flex; align-items: center; gap: 15px; }
    .cart-icon, .menu-icon { color: var(--white); padding: 5px; }
    .cart-icon i { margin-right: 5px; }
    .banner-section { position: relative; width: 100%; height: 220px; margin-bottom: 20px; }
    .banner-image-placeholder { width: 100%; height: 100%; background-image: url('https://placehold.co/1200x220/888888/FFFFFF?text=Menu+Banner+Image'); background-size: cover; background-position: center; background-blend-mode: multiply; background-color: rgba(0, 0, 0, 0.3); }
    /* Specific background for Food Hall */
    .foodhall-banner-bg { background-image: url('images/foodhall.jpg'); } 
    .info-badges { position: absolute; bottom: 20px; left: 20px; display: flex; gap: 10px; }
    .badge { padding: 5px 10px; border-radius: 50px; font-size: 0.75em; font-weight: bold; color: var(--white); display: flex; align-items: center; }
    .badge i { margin-right: 4px; }
    .badge-rating { background-color: var(--yellow-accent); color: var(--dark-text); }
    .badge-wait-time { background-color: rgba(0, 0, 0, 0.6); }
    .badge-choice { background-color: var(--red-icon); }
    .menu-page { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
    .filter-section { padding: 20px; background-color: var(--white); box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05); margin-bottom: 20px; }
    .filter-section h2 { font-size: 1.1em; font-weight: 600; margin-bottom: 15px; }
    .roulette-button { width: 100%; background-color: var(--yellow-accent); color: var(--dark-text); border: none; padding: 12px 0; border-radius: 8px; font-size: 1em; font-weight: bold; cursor: pointer; margin: 20px 0 15px; transition: background-color 0.2s; }
    .roulette-button:hover { background-color: #f7b731; }
    .roulette-button i { margin-right: 8px; }
    .menu-item-count { font-size: 0.9em; font-weight: 600; color: var(--dark-text); padding-top: 15px; border-top: 1px solid var(--border-color); }
    .menu-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; padding-top: 10px; padding-bottom: 50px; }
    .menu-separator { border: none; border-top: 2px solid #E9ECEF; margin: 15px 0 25px 0; width: auto; margin-left: auto; margin-right: auto; }
    .menu-card { background-color: var(--white); border-radius: 8px; overflow: hidden; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05); }
    .card-image-box { width: 100%; height: 150px; overflow: hidden; }
    .menu-item-image { width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s; }
    .menu-card:hover .menu-item-image { transform: scale(1.05); }
    .card-details { padding: 15px; }
    .card-details h3 { font-size: 1.1em; font-weight: 600; margin-bottom: 5px; }
    .price { font-size: 1em; font-weight: bold; color: var(--mapua-red); margin-bottom: 10px; }
    .add-to-cart-btn { width: 100%; background-color: var(--mapua-red); color: var(--white); border: none; padding: 10px 0; border-radius: 5px; font-size: 0.95em; font-weight: 600; cursor: pointer; transition: background-color 0.2s; }
    .add-to-cart-btn:hover { background-color: #A30A27; }
    .add-to-cart-btn:disabled { background-color: var(--text-muted); cursor: not-allowed; }
    @media (max-width: 992px) { .menu-grid { grid-template-columns: repeat(2, 1fr); } }
    @media (max-width: 600px) { .menu-grid { grid-template-columns: 1fr; padding: 0 15px 30px; } .header-content { align-items: flex-start; flex-direction: column; gap: 10px; } .stall-info { margin-left: 40px; } .header-actions { width: 100%; justify-content: flex-end; } }
</style>
</head>
<body>

    <header class="menu-header">
        <div class="header-content">
            <a href="customer_dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i></a>
            <div class="stall-info">
                <h1 id="stall-name">Loading...</h1>
                <p id="stall-description">Loading details...</p>
            </div>
            <div class="header-actions">
                <a href="Cart.php" class="cart-icon"><i class="fas fa-shopping-cart"></i> Cart</a>
                <a href="#" class="menu-icon"><i class="fas fa-ellipsis-v"></i></a>
            </div>
        </div>
    </header>

    <main class="menu-page">
        
        <div class="banner-section">
            <div class="banner-image-placeholder foodhall-banner-bg" id="stall-banner">
                <div class="info-badges">
                    <span class="badge badge-rating" id="stall-rating"><i class="fas fa-star"></i> ...</span>
                    <span class="badge badge-wait-time" id="stall-wait-time"><i class="far fa-clock"></i> ...</span>
                    <span class="badge badge-choice" id="stall-choice" style="display:none;"><i class="fas fa-heart"></i> Customer's Choice</span>
                </div>
            </div>
        </div>
            
            <p class="menu-item-count" id="stall-item-count">Loading menu...</p>
        </div>
            
        <hr class="menu-separator">

        <div class="menu-grid" id="menu-grid">
            </div>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const storeName = "Food Hall"; // IMPORTANT: Target the specific stall data
            
            // --- 1. Get references to all dynamic elements ---
            const stallNameEl = document.getElementById('stall-name');
            const stallDescEl = document.getElementById('stall-description');
            const stallBannerEl = document.getElementById('stall-banner');
            const stallRatingEl = document.getElementById('stall-rating');
            const stallWaitTimeEl = document.getElementById('stall-wait-time');
            const stallItemCountEl = document.getElementById('stall-item-count');
            const menuGridEl = document.getElementById('menu-grid');
            const rouletteButton = document.getElementById('roulette-button');
            
            let rouletteItems = []; // Array for the roulette

            // --- 2. Function to fetch all data from the API ---
            function loadMenu() {
                // Fetch data from get_store_menu.php
                fetch(`get_store_menu.php?store_name=${encodeURIComponent(storeName)}`)
                    .then(response => {
                        if (!response.ok) { throw new Error(`HTTP error! Status: ${response.status}`); }
                        return response.json();
                    })
                    .then(data => {
                        if (data.error) {
                            throw new Error(data.error);
                        }
                        
                        // --- 2a. Populate Store Info ---
                        const info = data.store_info;
                        stallNameEl.textContent = info.name || "Food Hall"; // Default friendly name
                        stallDescEl.textContent = info.description || 'Classic Filipino breakfast and comfort meals';
                        stallBannerEl.classList.add('foodhall-banner-bg'); 

                        // Format rating
                        const rating = parseFloat(info.avg_rating).toFixed(1);
                        stallRatingEl.innerHTML = `<i class="fas fa-star"></i> ${rating} (${info.review_count} reviews)`;
                        stallWaitTimeEl.innerHTML = `<i class="far fa-clock"></i> ${info.avg_wait_time}`;
                        
                        // Optionally show the 'Customer's Choice' badge based on data
                        if (info.is_popular) {
                            document.getElementById('stall-choice').style.display = 'flex';
                        }

                        // --- 2b. Populate Menu Items ---
                        const items = data.menu_items;
                        menuGridEl.innerHTML = ''; // Clear any loading content
                        
                        if (items.length === 0) {
                            stallItemCountEl.textContent = "This stall is currently not selling any items.";
                            return;
                        }

                        stallItemCountEl.textContent = `Menu (${items.length} items)`;
                        
                        items.forEach(item => {
                            // Add item name to roulette list
                            rouletteItems.push(item.name);
                            
                            // Create the menu card HTML
                            const card = document.createElement('div');
                            card.className = 'menu-card';
                            
                            // Check if item is available
                            const isAvailable = item.is_available;
                            const buttonDisabled = isAvailable ? '' : 'disabled';
                            const buttonText = isAvailable ? '<i class="fas fa-plus"></i> Add to Cart' : 'Out of Stock';
                            
                            // Format price to 2 decimal places (standard for currency)
                            const formattedPrice = Number(item.price).toFixed(2);

                            card.innerHTML = `
                                <div class="card-image-box">
                                    <img src="${item.image_url}" alt="${item.name}" class="menu-item-image">
                                </div>
                                <div class="card-details">
                                    <h3>${item.name}</h3>
                                    <p class="price">₱${formattedPrice}</p>
                                    <button class="add-to-cart-btn" data-item-id="${item.item_id}" ${buttonDisabled}>
                                        ${buttonText}
                                    </button>
                                </div>
                            `;
                            menuGridEl.appendChild(card);
                        });
                        
                        // --- 2c. Add event listeners to NEW buttons ---
                        addCartButtonListeners();

                    })
                    .catch(error => {
                        console.error('Fetch error:', error);
                        stallItemCountEl.textContent = `Error loading menu: ${error.message}`;
                    });
            }

            // --- 3. Function to add listeners to all cart buttons ---
            function addCartButtonListeners() {
                const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
                addToCartButtons.forEach(button => {
                    button.addEventListener('click', (event) => {
                        const itemID = event.target.dataset.itemId;
                        if (!itemID) return;
                        
                        // Get item details from the card
                        const card = event.target.closest('.menu-card');
                        const itemName = card.querySelector('h3').innerText;

                        addItemToCart(itemID, itemName, event.target);
                    });
                });
            }

            // --- 4. Add to Cart function (uses API) ---
            function addItemToCart(itemID, itemName, button) {
                // Show user feedback immediately
                const originalText = button.innerHTML;
                button.disabled = true;
                button.innerHTML = 'Adding...';

                fetch('cart_api.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'add',
                        item_id: itemID
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        throw new Error(data.error);
                    }
                    
                    // Success!
                    button.innerHTML = 'Added!';
                    setTimeout(() => { // Reset button after a moment
                        button.disabled = false;
                        button.innerHTML = originalText;
                    }, 1000);
                })
                .catch(err => {
                    console.error('Cart API error:', err);
                    alert(`Error adding ${itemName} to cart: ${err.message}`); 
                    button.disabled = false; // Re-enable button on fail
                    button.innerHTML = originalText;
                });
            }

            // --- 5. Roulette Button Logic ---
            if (rouletteButton) {
                rouletteButton.addEventListener('click', () => {
                    if (rouletteItems.length === 0) {
                        alert('Menu is still loading or empty!');
                        return;
                    }
                    const randomItem = rouletteItems[Math.floor(Math.random() * rouletteItems.length)];
                    alert('Try: ' + randomItem + '!');
                });
            }

            // --- 6. Run the main function ---
            loadMenu();
        });
    </script>
</body>
</html>