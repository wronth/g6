<?php
session_start();
require 'db_connect.php'; // Include your database connection

// ---
// Placeholder for your login system.
// In a real login.php, you would set $_SESSION['user_id']
// For this demo, we will use user_id = 1 (the "Demo User" you created)
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1; 
}
// ---

$user_id = $_SESSION['user_id'];
$user_name = "Guest"; // Default

try {
    $stmt = $pdo->prepare("SELECT first_name, last_name FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if ($user) {
        // Combine the first and last name (e.g., "Juan Dela Cruz")
        $user_name = $user['first_name'] . ' ' . $user['last_name'];
    }
} catch (PDOException $e) {
    // Handle error, but don't stop the page from loading
    error_log("Database error: " . $e->getMessage());
    $user_name = "Error";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Cardinal Pitstop - Customer Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
  :root{
    --mapua-red: #C60C30;
    --mapua-red-dark: #a20b27;
    --sidebar-open: 260px;
    --sidebar-collapsed: 64px;
    --bg: #f6f7f9;
    --text: #222;
    --card: #fff;
  }
  *{box-sizing:border-box}
  html,body{height:100%}
  body{
    margin:0;
    font-family: Inter, "Segoe UI", Roboto, Arial, sans-serif;
    background:var(--bg);
    color:var(--text);
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale;
  }

  /* ---------- SIDEBAR ---------- */
  .sidebar{
    position:fixed;
    left:0;
    top:0;
    height:100vh;
    width:var(--sidebar-collapsed);
    background: linear-gradient(180deg, var(--mapua-red) 0%, #b60f2b 100%);
    color:#fff;
    padding:14px 10px;
    display:flex;
    flex-direction:column;
    align-items:center;
    gap:14px;
    transition: width .26s cubic-bezier(.2,.9,.3,1);
    box-shadow: 0 6px 24px rgba(0,0,0,0.08);
    border-right: 1px solid rgba(255,255,255,0.03);
    z-index:40;
  }
  .sidebar.open{ width: var(--sidebar-open); padding:20px 18px; }

  /* ---------- Minimal hamburger (slim 3 dashes) ---------- */
  /* place the toggle neatly at top-left inside the sidebar */
  .menu-toggle {
    width: 44px;
    height: 44px;
    border-radius: 10px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: transparent;      
    cursor: pointer;
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    border: none;
    -webkit-tap-highlight-color: transparent;
    transition: background .14s, transform .12s;
  }

  /* When sidebar is open, move the toggle to the right edge */
  .sidebar.open .menu-toggle {
    align-self: flex-end;
    margin-right: 8px;
  }

  /* focus / keyboard visible ring */
  .menu-toggle:focus {
    outline: none;
    box-shadow: 0 0 0 4px rgba(255,255,255,0.08), 0 2px 6px rgba(0,0,0,0.12);
    border-radius: 10px;
  }

  /* wrapper for bars to make centering consistent */
  .menu-toggle .bars {
    display:flex;
    flex-direction:column;
    align-items:center;
    justify-content:center;
  }

  /* each dash */
  .menu-toggle .bar {
    width: 16px;        /* short dash look */
    height: 3px;        /* slightly thicker so it's visible and neat */
    background: #fff;   /* white on red */
    display: block;
    border-radius: 2px;
    transition: transform .22s, opacity .22s;
  }
  .menu-toggle .bar + .bar { margin-top: 6px; } /* breathing room between dashes */

  /* When sidebar open, animate into an X */
  .sidebar.open .menu-toggle .bar:nth-child(1){ transform: translateY(9px) rotate(45deg); }
  .sidebar.open .menu-toggle .bar:nth-child(2){ opacity:0; transform: scaleX(0); }
  .sidebar.open .menu-toggle .bar:nth-child(3){ transform: translateY(-9px) rotate(-45deg); }

  /* left column container inside sidebar (nav contents) */
  .sidebar-content{
    width:100%;
    margin-top:6px;
    display:flex;
    flex-direction:column;
    gap:10px;
    align-items:flex-start;
    opacity:0;
    transform:translateX(-8px);
    transition: opacity .22s, transform .22s;
    pointer-events:none;
  }
  .sidebar.open .sidebar-content{
    opacity:1;
    transform:none;
    pointer-events:auto;
  }

  .brand{ display:none; font-weight:700; font-size:25px; color:rgba(255,255,255,0.95); }
  .sidebar.open .brand{ display:block; }

  .nav-list{ list-style:none; padding:0; margin:8px 0 0 0; width:100%; }
  .nav-item{ width:100%; }
  .nav-item a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:10px 12px;
    color:#fff;
    text-decoration:none;
    border-radius:10px;
    background:transparent;
    transition: background .14s, transform .12s;
    width:100%;
  }
  .nav-item a i { min-width:18px; text-align:center; }
  .nav-item a:hover{ background: rgba(255,255,255,0.08); transform: translateX(4px); }

  /* hide labels when collapsed */
  .sidebar:not(.open) .label{ display:none; }

  .sidebar-footer{ margin-top:auto; width:100%; }
  .logout-btn{
    display:flex;
    gap:10px;
    align-items:center;
    padding:10px 12px;
    border-radius:10px;
    text-decoration:none;
    color:#fff;
    background: rgba(0,0,0,0.06);
  }

  /* Flip the sign-out icon to point left (only affects the icon inside .logout-btn) */
  .logout-btn i.fas.fa-sign-out-alt {
    display: inline-block;
    transform: scaleX(-1);
    transform-origin: center;
  }

  /* ---------- MAIN ---------- */
  main{
    margin-left: var(--sidebar-collapsed);
    padding:20px 28px;
    width: calc(100% - var(--sidebar-collapsed));
    transition: margin-left .26s, width .26s;
    min-height:100vh;
  }
  .sidebar.open ~ main{
    margin-left: var(--sidebar-open);
    width: calc(100% - var(--sidebar-open));
  }

  /* top row - greeting and search */
  .page-top{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:16px;
    margin-bottom:18px;
  }

  .page-greeting{
    font-size:45px;
    font-style: italic;
    color:#890e0e;
    font-weight:700;
    margin:0;
  }

  .search-wrapper{ width:420px; max-width:60%; }
  .search-input{
    width:100%;
    padding:12px 16px;
    border-radius:999px;
    border:1px solid #e6e7ea;
    background:#fff;
    box-shadow: 0 6px 20px rgba(33,33,33,0.04);
    font-size:15px;
  }
  .search-input:focus{ outline:none; box-shadow:0 10px 30px rgba(33,33,33,0.07); transform: translateY(-1px); }

  .content-wrapper{ max-width:1200px; margin:0 auto; }
  .section-title-icon{ font-size:18px; margin-bottom:12px; color:#333; display:flex; align-items:center; gap:8px; }

  .planner-box{
    background:var(--card);
    padding:14px;
    border-radius:12px;
    box-shadow: 0 8px 30px rgba(31,41,55,0.06);
    display:flex;
    justify-content:space-between;
    gap:12px;
    align-items:center;
    margin-bottom:20px;
  }
  .set-schedule-button{
    background:var(--mapua-red);
    color:#fff;
    border:none;
    padding:8px 14px;
    border-radius:10px;
    cursor:pointer;
  }

  .quick-access-grid, .store-grid{ display:flex; flex-wrap:wrap; gap:20px; }
  .quick-access-box, .store-card{
    background:var(--card);
    padding:15px;
    border-radius:12px;
    flex:1 1 250px;
    box-shadow: 0 8px 24px rgba(31,41,55,0.04);
  }

  @media (max-width:980px){
    .search-wrapper{ max-width:48%; }
    .page-greeting{ font-size:22px; }
  }
  @media (max-width:720px){
    .sidebar{ position:fixed; z-index:80; left:0; top:0; height:100%; }
    main{ margin-left: var(--sidebar-collapsed); width: calc(100% - var(--sidebar-collapsed)); padding:12px; }
    .search-wrapper{ max-width:55%; }
  }

  /* ----------- NEW CODE TO MAXIMIZE HORIZONTAL SPACE & ALIGN GREETING ----------- */
  .content-wrapper{
    max-width: none;
    width: calc(100% - 40px);
    margin: 0 auto;
    padding: 0 12px;
  }

  main {
    padding-left: 12px;
    padding-right: 12px;
  }

  /* Make .page-top align with the content-wrapper so the greeting lines up with section headings */
  .page-top{
    width: calc(100% - 40px);   /* same effective width as .content-wrapper */
    max-width: none;
    margin: 0 auto 18px;       /* center within main — aligns with content */
    padding-right: 12px;        /* avoid search hugging the edge */
  }

  .choice-of-week-grid,
  .full-stores-grid {
    gap: 24px;
    justify-content: flex-start;
  }

  .store-card {
    flex: 1 1 320px;
    min-width: 240px;
  }

  .store-image {
    width: 100%;
    height: 160px;
    object-fit: cover; /* <-- This crops the image to fit the 160px height */
    border-radius: 8px;
    margin-bottom: 12px;
    background: #eee;
  }

  .store-card-description {
    color: #666;
    font-size: 13px;
    margin-top: 6px;
    min-height: 40px; /* Ensures consistent card height by reserving space for 2 lines */
  }
  
  /* Style for the "No results" message */
  .no-results {
    display: none; /* Hidden by default */
    width: 100%;
    text-align: center;
    color: #666;
    padding: 40px 0;
    font-size: 1.1rem;
    font-weight: 500;
  }


  @media (min-width:1400px){
    .store-card { flex-basis: 28%; }
  }

  /* If the sidebar opens (wider left margin), keep .page-top visually aligned — minor tweak so the center calculation still works */
  .sidebar.open ~ main .page-top{
    width: calc(100% - 40px);
    margin-left: 0;
  }

  /* ================== CAROUSEL STYLES (UPDATED TO BE LARGE HERO-LIKE) ================== */
  .carousel {
    width:100%;
    max-width:1200px;        /* bigger, closer to full-width hero look */
    margin: 10px auto 18px;
    position: relative;
    overflow: visible;
  }

  .carousel-viewport {
    width:100%;
    overflow: hidden;
    border-radius: 16px;
    background: transparent;
  }

  .carousel-track {
    display:flex;
    gap:24px;
    transition: transform 420ms cubic-bezier(.22,.9,.3,1);
    will-change: transform;
    padding: 12px 8px;
    align-items: center;
  }

  .carousel-slide {
    background: #fff;
    min-width: calc(100% - 48px); /* show one slide at a time */
    flex: 0 0 calc(100% - 48px);
    border-radius: 12px;
    box-shadow: 0 12px 40px rgba(31,41,55,0.08);
    display:flex;
    gap:20px;
    align-items:center;
    padding: 20px;
    text-decoration:none;
    color:inherit;
    overflow: visible;
  }

  /* big image thumb for real images */
  .carousel-slide img.thumb {
    width: 70%;
    height: 420px;
    min-width: 280px;
    max-width: calc(100% - 320px);
    object-fit: cover;
    border-radius: 12px;
    flex: 0 0 70%;
    display: block;
    box-shadow: 0 8px 30px rgba(0,0,0,0.06);
  }

  /* emoji / placeholder thumb when not an image */
  .carousel-slide .thumb:not(img) {
    width: 420px;
    height: 320px;
    border-radius: 12px;
    background: #fff;
    font-size: 80px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:var(--mapua-red);
    flex:0 0 420px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.06);
  }

  .carousel-slide .meta {
    flex:1;
    padding-left: 24px;
    display:flex;
    flex-direction:column;
    justify-content:center;
  }
  .carousel-slide h3 { margin:0 0 8px 0; font-size:28px; color:#111; }
  .carousel-slide p { margin:0 0 14px 0; color:#444; font-size:16px; line-height:1.3; }

  /* emphasized CTAs */
  .carousel-slide .set-schedule-button {
    background: var(--mapua-red);
    color: #fff;
    border: none;
    padding: 12px 20px;
    border-radius: 12px;
    font-size:16px;
    cursor: pointer;
    box-shadow: 0 6px 18px rgba(198,12,48,0.12);
    align-self:flex-start;
  }

  /* controls */
  .carousel-btn {
    position:absolute;
    top:50%;
    transform:translateY(-50%);
    background: rgba(255,255,255,0.95);
    border:none;
    box-shadow: 0 6px 18px rgba(31,41,55,0.08);
    width:48px;
    height:48px;
    border-radius:10px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    cursor:pointer;
    z-index:5;
  }
  .carousel-btn:focus{ outline: none; box-shadow:0 0 0 6px rgba(198,12,48,0.08); }
  .carousel-prev{ left: 8px; }
  .carousel-next{ right: 8px; }

  /* indicators */
  .carousel-dots {
    display:flex;
    gap:8px;
    justify-content:center;
    margin-top:12px;
  }
  .carousel-dot {
    width:12px;
    height:12px;
    border-radius:50%;
    background: #e6e6e6;
    border:none;
    cursor:pointer;
  }
  .carousel-dot.active { background: var(--mapua-red); }

  /* Responsive: stack on small widths to keep image prominent but not huge */
  @media (max-width:1000px){
    .carousel-slide img.thumb { width: 60%; height: 320px; flex: 0 0 60%; }
    .carousel-slide .thumb:not(img) { width: 300px; height: 240px; flex:0 0 300px; font-size:64px; }
    .carousel-slide { padding:16px; min-width: calc(100% - 36px); }
  }

  @media (max-width:720px){
    .carousel {
      max-width: 100%;
      margin: 8px auto 12px;
    }
    .carousel-slide {
      flex-direction: column;
      align-items: stretch;
      padding: 12px;
      min-width: calc(100% - 24px);
    }
    .carousel-slide img.thumb { width: 100%; height: auto; max-height: 320px; flex: none; }
    .carousel-slide .thumb:not(img) { width: 220px; height: 220px; margin: 0 auto; flex: none; }
    .carousel-slide .meta { padding-left: 0; margin-top: 14px; text-align: center; }
    .carousel-prev{ left: 4px; }
    .carousel-next{ right: 4px; }
    .carousel-btn { width:40px; height:40px; }
  }
  /* ========================================================== */

</style>
</head>
<body>

  <aside class="sidebar" id="sidebar" aria-hidden="false">
    <button class="menu-toggle" id="menuToggle" aria-label="Open menu" title="Open menu" aria-expanded="false" type="button">
      <span class="bars" aria-hidden="true">
        <span class="bar"></span>
        <span class="bar"></span>
        <span class="bar"></span>
      </span>
    </button>

    <div class="brand">Cardinal Pitstop</div>

    <nav class="sidebar-content" aria-label="Main navigation">
      <ul class="nav-list" role="menu">
        <li class="nav-item"><a href="Cart.php" id="navCart"><i class="fas fa-shopping-cart"></i><span class="label">Cart</span></a></li>
        <li class="nav-item"><a href="Orders.php" id="navOrders"><i class="fas fa-receipt"></i><span class="label">Orders</span></a></li>
        <li class="nav-item"><a href="Expenses.html" id="navExpenses"><i class="fas fa-wallet"></i><span class="label">Expenses</span></a></li>
        <li class="nav-item"><a href="CustomerSchedule.html" id="navSchedule"><i class="far fa-calendar-check"></i><span class="label">Schedule</span></a></li>
      </ul>
    </nav>

    <div class="sidebar-footer">
      <a href="login.html" class="logout-btn" id="logoutBtn"><i class="fas fa-sign-out-alt"></i><span class="label">Logout</span></a>
    </div>
  </aside>

  <main>
    <div class="page-top">
      <!-- THIS IS THE LINE I'M CHANGING -->
      <h1 class="page-greeting" id="pageGreeting">Hey, <span id="pageUserName"><?php echo htmlspecialchars($user_name); ?></span></h1>

      <div class="search-wrapper" style="display:flex;align-items:center;justify-content:flex-end;">
        <form id="searchForm" style="width:100%" onsubmit="return false;">
          <input id="searchInput" class="search-input" type="search" placeholder="🔍 What do you want to eat today..." aria-label="Search stores">
        </form>
      </div>
    </div>

    <div class="content-wrapper">
      <div class="section-title-icon">What are you craving for today?</div>

      <!-- ====== Carousel START (replaces the single quick-access card) ====== -->
      <div class="carousel" id="mainCarousel" aria-roledescription="carousel">
        <div class="carousel-viewport" role="region" aria-live="polite">
          <div class="carousel-track" id="carouselTrack">
            <!-- Slide 1: Roulette (wrap is a link so whole slide is clickable) -->
            <a class="carousel-slide" href="roulette.html" role="link" aria-label="Spin the Store Roulette">
              <div class="thumb">🎲</div>
              <div class="meta">
                <h3>Spin the Roulette</h3>
                <p>Can't decide? Let us pick for you — spin now and try your luck.</p>
                <button class="set-schedule-button" aria-hidden="false" type="button">Spin</button>
              </div>
            </a>

            <!-- Slide 2: Featured Store -->
            <a class="carousel-slide" href="potatostall.php" role="link" aria-label="Featured: Potato Stall">
              <img src="images/potatostall.jpg" alt="Potato Stall" class="thumb">
              <div class="meta">
                <h3>Featured: Potato Stall</h3>
                <p>Crispy treats top-rated this week — order a snack now.</p>
                <div style="margin-top:8px;"><span style="color:#666;font-size:13px">Open • 4.8★</span></div>
              </div>
            </a>

            <!-- Slide 3: Today's Deal -->
            <a class="carousel-slide" href="kopee.html" role="link" aria-label="Today's Deal: Kopee">
              <img src="images/kopee.jpg" alt="Kopee" class="thumb">
              <div class="meta">
                <h3>Today's Deal: Kopee</h3>
                <p>Buy-one-get-one on selected beverages for a limited time.</p>
                <div style="margin-top:8px;"><strong style="color:var(--mapua-red)">Save Now</strong></div>
              </div>
            </a>
          </div>
        </div>

        <!-- controls -->
        <button class="carousel-btn carousel-prev" id="carouselPrev" aria-label="Previous slide" title="Previous">
          <i class="fas fa-chevron-left"></i>
        </button>
        <button class="carousel-btn carousel-next" id="carouselNext" aria-label="Next slide" title="Next">
          <i class="fas fa-chevron-right"></i>
        </button>

        <!-- dots -->
        <div class="carousel-dots" id="carouselDots" role="tablist" aria-label="Carousel indicators"></div>
      </div>
      <!-- ====== Carousel END ====== -->

      <div class="quick-access-grid" style="margin-bottom:12px">
        <!-- (kept for layout parity; carousel replaces the main quick access functionality above) -->
      </div>

      <h2 style="margin-top:20px; font-size:18px">👑 Customer's Choice of the Week</h2>
      <p style="color:#666;margin-top:6px;margin-bottom:12px">Top-rated favorites by Mapúa customers</p>

      <div class="store-grid choice-of-week-grid">
        <a href="potatostall." style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card small-card">
            <img src="images/potatostall.jpg" alt="potatostall" class="store-image">
            <strong>Potato Stall</strong>
            <div class="store-card-description">Crispy potato treats and comfort snacks</div>
          </div>
        </a>

        <a href="sinpao.php" style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card small-card">
            <img src="images/sinpao.jpg" alt="Sinpao" class="store-image">
            <strong>Sinpao</strong>
            <div class="store-card-description">Authentic Asian cuisine and flavorful rice meals</div>
          </div>
        </a>

        <a href="baibaibanana.php" style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card small-card">
            <img src="images/baibaibanana.jpg" alt="baibaibanana" class="store-image">
            <strong>Baibai Banana</strong>
            <div class="store-card-description">Sweet treats and refreshing bingsu desserts</div>
          </div>
        </a>
        <div id="no-results-choice" class="no-results">No stores found matching your search.</div>
      </div>
      <h2 style="margin-top:26px">Browse All Stores</h2>
      <p style="color:#666;margin-bottom:12px">Explore all available food options</p>

      <div class="store-grid full-stores-grid" style="margin-bottom:60px;">
    
        <a href="potatostall.html" style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card">
            <img src="images/potatostall.jpg" alt="potatostall" class="store-image">
            <strong>Potato Stall</strong>
            <div class="store-card-description">Crispy potato treats and comfort snacks</div>
          </div>
        </a>
    
        <a href="sinpao.php" style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card">
            <img src="images/sinpao.jpg" alt="Sinpao" class="store-image">
            <strong>Sinpao</strong>
            <div class="store-card-description">Authentic Asian cuisine and flavorful rice meals</div>
          </div>
        </a>
    
        <a href="kopee.php" style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card">
            <img src="images/kopee.jpg" alt="kopee" class="store-image">
            <strong>Kopee</strong>
            <div class="store-card-description">Premium coffee and specialty beverages</div>
          </div>
        </a>
    
        <a href="African.php" style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card">
            <img src="images/african.jpg" alt="african" class="store-image">
            <strong>African</strong>
            <div class="store-card-description">Hearty beef and chicken specialties</div>
          </div>
        </a>
    
        <a href="PancitNoodle.php" style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card">
            <img src="images/pancitnoodle.jpg" alt="pancitnoodle" class="store-image">
            <strong>Pancit Noodles</strong>
            <div class="store-card-description">Classic Filipino pancit and noodle dishes</div>
          </div>
        </a>
    
        <a href="baibaibanana.php" style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card">
            <img src="images/baibaibanana.jpg" alt="baibaibanana" class="store-image">
            <strong>Baibai Banana</strong>
            <div class="store-card-description">Sweet treats and refreshing bingsu desserts</div>
          </div>
        </a>
    
        <a href="FoodHall.php" style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card">
            <img src="images/foodhall.jpg" alt="foodhall" class="store-image">
            <strong>Food Hall</strong>
            <div class="store-card-description">A wide variety of meals and dining choices</div>
          </div>
        </a>
    
        <a href="SkyRoast.php" style="display:block;text-decoration:none;color:inherit" class="store-link">
          <div class="store-card">
            <img src="images/skyroast.jpg" alt="skyroast" class="store-image">
            <strong>Sky Roast</strong>
            <div class="store-card-description">Juicy chicken and savory meals</div>
          </div>
        </a>
        <div id="no-results-all" class="no-results">No stores found matching your search.</div>
      </div>
      </div>
  </main>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    const menuToggle = document.getElementById('menuToggle');
    const logoutBtn = document.getElementById('logoutBtn');
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');

    // toggle open/close
    menuToggle.addEventListener('click', () => {
      const open = sidebar.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    // keyboard accessible
    menuToggle.addEventListener('keydown', (e) => {
      if(e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const open = sidebar.classList.toggle('open');
        menuToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      }
    });

    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.href = 'login.html';
    });

    // --- Carousel logic (new) ---
    (function initCarousel() {
      const track = document.getElementById('carouselTrack');
      const slides = Array.from(track.querySelectorAll('.carousel-slide'));
      const prevBtn = document.getElementById('carouselPrev');
      const nextBtn = document.getElementById('carouselNext');
      const dotsContainer = document.getElementById('carouselDots');

      let currentIndex = 0;
      let autoplayId = null;
      const autoplayDelay = 4000;
      let isHovering = false;
      let startX = null;
      let deltaX = 0;
      const slideCount = slides.length;

      // create dots
      slides.forEach((_, i) => {
        const dot = document.createElement('button');
        dot.className = 'carousel-dot';
        dot.setAttribute('aria-label', `Go to slide ${i+1}`);
        dot.setAttribute('role', 'tab');
        dot.addEventListener('click', () => goTo(i));
        dotsContainer.appendChild(dot);
      });

      const dots = Array.from(dotsContainer.children);

      function update() {
        // Add a check for slides[0]
        if (!slides[0]) return;
        const slideWidth = slides[0].getBoundingClientRect().width + 24; // include gap
        const offset = currentIndex * slideWidth;
        track.style.transform = `translateX(-${offset}px)`;
        dots.forEach((d, i) => d.classList.toggle('active', i === currentIndex));
      }

      function prev() {
        currentIndex = (currentIndex - 1 + slideCount) % slideCount;
        update();
        resetAutoplay();
      }
      function next() {
        currentIndex = (currentIndex + 1) % slideCount;
        update();
        resetAutoplay();
      }
      function goTo(i) {
        currentIndex = (i + slideCount) % slideCount;
        update();
        resetAutoplay();
      }

      prevBtn.addEventListener('click', prev);
      nextBtn.addEventListener('click', next);

      // autoplay
      function startAutoplay() {
        if (autoplayId) return;
        autoplayId = setInterval(() => {
          if (!isHovering) next();
        }, autoplayDelay);
      }
      function stopAutoplay() {
        clearInterval(autoplayId);
        autoplayId = null;
      }
      function resetAutoplay() {
        stopAutoplay();
        startAutoplay();
      }

      // pause on hover/focus
      const carousel = document.getElementById('mainCarousel');
      carousel.addEventListener('mouseenter', () => { isHovering = true; });
      carousel.addEventListener('mouseleave', () => { isHovering = false; });
      carousel.addEventListener('focusin', () => { isHovering = true; });
      carousel.addEventListener('focusout', () => { isHovering = false; });

      // keyboard arrows
      document.addEventListener('keydown', (e) => {
        if (document.activeElement && (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA')) return;
        if (e.key === 'ArrowLeft') prev();
        if (e.key === 'ArrowRight') next();
      });

      // simple touch / swipe
      track.addEventListener('pointerdown', (e) => {
        startX = e.clientX;
        deltaX = 0;
        track.setPointerCapture(e.pointerId);
      });
      track.addEventListener('pointermove', (e) => {
        if (startX === null) return;
        deltaX = e.clientX - startX;
      });
      track.addEventListener('pointerup', (e) => {
        if (Math.abs(deltaX) > 50) {
          if (deltaX > 0) prev();
          else next();
        }
        startX = null;
        deltaX = 0;
      });

      // responsive: recalc on resize to ensure smooth centering
      window.addEventListener('resize', () => {
        // small timeout to allow layout to settle
        setTimeout(update, 120);
      });

      // initialize UI
      update();
      startAutoplay();

      // Ensure the "Spin" button inside the first slide definitely navigates to roulette.html
      try {
        const firstSlide = slides[0];
        const spinBtn = firstSlide.querySelector('.set-schedule-button');
        if (spinBtn) {
          spinBtn.addEventListener('click', (ev) => {
            ev.preventDefault();
            // navigate explicitly
            window.location.href = 'roulette.html';
          });
        }
      } catch (err) {
        // fail silently — carousel still works
      }
    })();

    // --- Search Functionality (existing) ---
    const allStoreLinks = document.querySelectorAll('.store-link');
    const choiceGrid = document.querySelector('.choice-of-week-grid');
    const allStoresGrid = document.querySelector('.full-stores-grid');
    const noResultsChoice = document.getElementById('no-results-choice');
    const noResultsAll = document.getElementById('no-results-all');

    function filterStores() {
        const searchTerm = searchInput.value.toLowerCase().trim();
        let choiceVisibleCount = 0;
        let allVisibleCount = 0;

        allStoreLinks.forEach(link => {
            const storeName = link.querySelector('strong')?.textContent.toLowerCase() || '';
            const description = link.querySelector('.store-card-description')?.textContent.toLowerCase() || '';
            
            const isMatch = storeName.includes(searchTerm) || description.includes(searchTerm);
            
            if (isMatch) {
                link.style.display = 'block';
                // Check which grid it belongs to
                if (choiceGrid.contains(link)) {
                    choiceVisibleCount++;
                }
                if (allStoresGrid.contains(link)) {
                    allVisibleCount++;
                }
            } else {
                link.style.display = 'none';
            }
        });

        // Show/hide "No results" message for 'Choice of the Week'
        if (noResultsChoice) {
            noResultsChoice.style.display = choiceVisibleCount === 0 && searchTerm ? 'block' : 'none';
        }
        
        // Show/hide "No results" message for 'All Stores'
        if (noResultsAll) {
            noResultsAll.style.display = allVisibleCount === 0 && searchTerm ? 'block' : 'none';
        }
    }

    // search submit on Enter (runs the filter)
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      filterStores();
    });

    // Add live search on input
    searchInput.addEventListener('input', filterStores);
  });
</script>
</body>
</html>
