<?php
// Include the database connection
require 'db_connect.php';

// Set the response type to JSON
header('Content-Type: application/json');

// Get the store_id based on the store_name (passed in the URL)
function getStoreId($pdo, $store_name) {
    if (empty($store_name)) {
        return null;
    }
    // Note: Assuming 'name' column is unique or correctly identifies the single store owner.
    $stmt = $pdo->prepare("SELECT store_id FROM stores WHERE name = ?");
    $stmt->execute([$store_name]);
    $store = $stmt->fetch();
    return $store ? $store['store_id'] : null;
}

// Store the store name and ID in variables
$store_name = $_GET['store_name'] ?? '';
$store_id = getStoreId($pdo, $store_name);

if (!$store_id) {
    echo json_encode(['error' => "Store not found: " . htmlspecialchars($store_name)]);
    exit;
}

// Check if it's a "GET" request (to load data) or "POST" (to make changes)
$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        // --- THIS IS FOR LOADING ALL DATA ON PAGE LOAD ---

        // 1. Get Inventory
        $stmt_inv = $pdo->prepare("
            SELECT item_id AS id, name, price, stock_quantity AS stock 
            FROM menu_items 
            WHERE store_id = ?
        ");
        $stmt_inv->execute([$store_id]);
        $inventory = $stmt_inv->fetchAll();

        // 2. Get Orders (with customer names)
        $stmt_ord = $pdo->prepare("
            SELECT 
                o.order_id AS id, 
                o.status, 
                o.order_time AS datetime, 
                o.total_amount AS amount, 
                o.pickup_code, 
                CONCAT(u.first_name, ' ', u.last_name) AS customer
            FROM orders o
            JOIN users u ON o.user_id = u.user_id
            WHERE o.store_id = ?
            ORDER BY o.order_time DESC
        ");
        $stmt_ord->execute([$store_id]);
        $orders = $stmt_ord->fetchAll();

        // 3. Get items for each order
        $stmt_items = $pdo->prepare("
            SELECT item_name_snapshot AS name, quantity AS qty, price_at_order AS price 
            FROM order_items 
            WHERE order_id = ?
        ");
        foreach ($orders as $key => $order) {
            $stmt_items->execute([$order['id']]);
            $orders[$key]['items'] = $stmt_items->fetchAll();
        }

        // 4. Send all data back as JSON
        echo json_encode(['inventory' => $inventory, 'orders' => $orders]);

    } elseif ($method === 'POST') {
        // --- THIS IS FOR SAVING, ADDING, DELETING, OR UPDATING ---
        
        $data = json_decode(file_get_contents('php://input'), true);
        $action = $data['action'] ?? '';

        switch ($action) {
            case 'add_product':
                $stmt = $pdo->prepare("INSERT INTO menu_items (store_id, name, price, stock_quantity) VALUES (?, ?, ?, ?)");
                $stmt->execute([$store_id, $data['name'], $data['price'], $data['stock']]);
                $new_id = $pdo->lastInsertId();
                echo json_encode(['success' => true, 'new_id' => $new_id]);
                break;
            
            case 'update_inventory':
                $stmt = $pdo->prepare("UPDATE menu_items SET price = ?, stock_quantity = ? WHERE item_id = ? AND store_id = ?");
                $stmt->execute([$data['price'], $data['stock'], $data['id'], $store_id]);
                echo json_encode(['success' => true]);
                break;
                
            case 'delete_product':
                $stmt = $pdo->prepare("DELETE FROM menu_items WHERE item_id = ? AND store_id = ?");
                $stmt->execute([$data['id'], $store_id]);
                echo json_encode(['success' => true]);
                break;

            case 'update_status':
                $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE order_id = ? AND store_id = ?");
                $stmt->execute([$data['status'], $data['id'], $store_id]);
                echo json_encode(['success' => true]);
                break;

            case 'process_order':
                $order_id = $data['id'];
                $status = $data['status']; // Should be 'completed'
                $items = $data['items'];
                
                // Check if the order is already completed to prevent double-processing
                $stmt_check = $pdo->prepare("SELECT status FROM orders WHERE order_id = ?");
                $stmt_check->execute([$order_id]);
                $current_status = $stmt_check->fetchColumn();

                if ($current_status === 'completed') {
                    echo json_encode(['success' => true, 'message' => 'Order already processed']);
                    break;
                }
                
                try {
                    $pdo->beginTransaction();

                    // 1. Update the order status to 'completed'
                    $stmt_update_order = $pdo->prepare("UPDATE orders SET status = ? WHERE order_id = ? AND store_id = ?");
                    $stmt_update_order->execute([$status, $order_id, $store_id]);

                    // 2. Decrement stock for each item
                    // We need item_id, but the order only stores name, so we look it up first.
                    $stmt_get_item_id = $pdo->prepare("SELECT item_id, stock_quantity FROM menu_items WHERE name = ? AND store_id = ?");
                    $stmt_decrement_stock = $pdo->prepare("
                        UPDATE menu_items 
                        SET stock_quantity = stock_quantity - ? 
                        WHERE item_id = ? AND store_id = ?
                    ");

                    foreach ($items as $item) {
                        $item_name = $item['name'];
                        $quantity = $item['qty'];

                        // a. Find the item ID and current stock
                        $stmt_get_item_id->execute([$item_name, $store_id]);
                        $item_info = $stmt_get_item_id->fetch();

                        if ($item_info) {
                            $item_id = $item_info['item_id'];
                            
                            // b. Decrement the stock
                            $stmt_decrement_stock->execute([$quantity, $item_id, $store_id]);
                        } else {
                            // If an item in the order is missing from the menu, roll back and error
                            throw new Exception("Inventory item '{$item_name}' not found for stock update.");
                        }
                    }

                    $pdo->commit();
                    echo json_encode(['success' => true]);

                } catch (Exception $e) {
                    $pdo->rollBack();
                    // Return a specific error message if the stock update fails
                    echo json_encode(['success' => false, 'error' => 'Processing failed: Stock adjustment error. ' . $e->getMessage()]);
                }
                break; // End of process_order case

            default:
                echo json_encode(['error' => 'Invalid action']);
        }
    }

} catch (PDOException $e) {
    // This catches general database connection or syntax errors outside the transaction block
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
