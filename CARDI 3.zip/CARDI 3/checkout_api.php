<?php
// This API file:
// 1. Reads all items from the user's cart.
// 2. Groups them by store.
// 3. Creates a separate, new order for EACH store.
// 4. Clears the user's cart.

require 'db_connect.php'; 
session_start(); 
header('Content-Type: application/json');

// ---
// Placeholder for your login system.
if (!isset($_SESSION['user_id'])) {
    $stmt = $pdo->query("SELECT user_id FROM users LIMIT 1");
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['user_id'] = $user['user_id'];
    } else {
        $_SESSION['user_id'] = 1; // Fallback
    }
}
$user_id = $_SESSION['user_id'];
// ---

if ($user_id === 0) {
    echo json_encode(['error' => 'You must be logged in to place an order.']);
    exit;
}

try {
    // Begin a database transaction
    // This means if ANY part fails, the whole thing is rolled back.
    $pdo->beginTransaction();

    // 1. Get all cart items for this user, locked for update
    $stmt_items = $pdo->prepare("
        SELECT 
            ci.item_id,
            ci.quantity,
            mi.name,
            mi.price,
            mi.store_id
        FROM cart_items ci
        JOIN menu_items mi ON ci.item_id = mi.item_id
        WHERE ci.user_id = ?
        FOR UPDATE
    ");
    $stmt_items->execute([$user_id]);
    $items = $stmt_items->fetchAll();

    if (empty($items)) {
        echo json_encode(['error' => 'Your cart is empty.']);
        $pdo->rollBack();
        exit;
    }

    // 2. Group items by store_id
    $items_by_store = [];
    foreach ($items as $item) {
        $items_by_store[$item['store_id']][] = $item;
    }

    // 3. Prepare statements for inserting orders
    $stmt_order = $pdo->prepare("
        INSERT INTO orders (user_id, store_id, total_amount, status, pickup_code)
        VALUES (?, ?, ?, 'pending', ?)
    ");
    
    $stmt_order_item = $pdo->prepare("
        INSERT INTO order_items (order_id, item_id, item_name_snapshot, price_at_order, quantity)
        VALUES (?, ?, ?, ?, ?)
    ");

    $created_order_ids = [];

    // 4. Create a new order for EACH store
    foreach ($items_by_store as $store_id => $store_items) {
        // Calculate total for this store's order
        $total_amount = 0;
        foreach ($store_items as $item) {
            $total_amount += $item['price'] * $item['quantity'];
        }

        // Generate a simple pickup code (e.g., "A123")
        $pickup_code = chr(rand(65, 90)) . rand(100, 999);

        // Create the main order
        $stmt_order->execute([
            $user_id,
            $store_id,
            $total_amount,
            $pickup_code
        ]);
        
        $order_id = $pdo->lastInsertId();
        $created_order_ids[] = $order_id;

        // Add all items to the order_items table
        foreach ($store_items as $item) {
            $stmt_order_item->execute([
                $order_id,
                $item['item_id'],
                $item['name'],
                $item['price'],
                $item['quantity']
            ]);
        }
    }

    // 5. Clear the user's cart
    $stmt_clear = $pdo->prepare("DELETE FROM cart_items WHERE user_id = ?");
    $stmt_clear->execute([$user_id]);

    // 6. Commit the transaction (everything was successful)
    $pdo->commit();

    echo json_encode([
        'success' => true, 
        'message' => 'Order(s) placed successfully!',
        'order_ids' => $created_order_ids
    ]);

} catch (PDOException $e) {
    // If anything went wrong, roll back all changes
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>

